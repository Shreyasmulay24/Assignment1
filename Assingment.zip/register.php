<?php
session_start();
if(isset($_SESSION["count"]))
{
$access=$_SESSION["count"]+1;
}
else
{
$access=1;
}
$_SESSION["count"]=$access;
?>
<html>
<body>
<h1 align="left">Visitors Count:-<?php echo $access;?></h1>
<?php 
$link = new mysqli('localhost', 'root', '', 'shreyas');
 $name=$_POST['name'];
$category=$_POST['t1'];
$des=$_POST['t3'];
$le=$_POST['t4'];
if($name!=NULL&&$category!=NULL&&$des!=NULL&&$le!=NULL)
{
$res=mysqli_query($link,"insert into animal values('$name','$category','$des','$le')");
} 

// If file upload form is submitted 
$status = $statusMsg = ''; 
if(isset($_POST["submit"])){ 
    $status = 'error'; 
    if(!empty($_FILES["image"]["name"])) { 
        // Get file info 
        $fileName = basename($_FILES["image"]["name"]); 
        $fileType = pathinfo($fileName, PATHINFO_EXTENSION); 
         
        // Allow certain file formats 
        $allowTypes = array('jpg','png','jpeg','gif'); 
        if(in_array($fileType, $allowTypes)){ 
            $image = $_FILES['image']['tmp_name']; 
            $imgContent = addslashes(file_get_contents($image)); 
         
            // Insert image content into database 
            $insert = $link->query("INSERT into images (image, uploaded) VALUES ('$imgContent', NOW())"); 
             
            if($insert){ 
                $status = 'success'; 
                $statusMsg = "File uploaded successfully."; 
            }else{ 
                $statusMsg = "File upload failed, please try again."; 
            }  
        }else{ 
            $statusMsg = 'Sorry, only JPG, JPEG, PNG, & GIF files are allowed to upload.'; 
        } 
    }else{ 
        $statusMsg = 'Please select an image file to upload.'; 
    } 
} 
 
// Display status message 
echo $statusMsg; 
?>
<?php 
 // Get image data from database 
$result = $link->query("SELECT image FROM images"); 
?>
<table  border=1 align="center">
<tr><td><h1>Animal Name</h1></td>
<td><h1>Category</h1></td>
<td><h1>Description</h1></td>
<td><h1>Life Expectancy</h1></td>
<td><h1>Image</h1></td></tr>
<?php if($result->num_rows > 0){ 
?> 
<div class="gallery"> 
        <?php 
$result1=$link ->query("SELECT * FROM animal");
while($row = $result->fetch_assoc())
{ 
if($row1=mysqli_fetch_array($result1))
{
		echo "<tr><td><h1 id='h'>".$row1['name']."</td>";
		echo "<td><h1 id='h'>".$row1['category']."</td>";
		echo "<td><h1 id='h'>".$row1['des']."</td>";
		echo "<td><h1 id='h'>".$row1['le']."</h1></td>";
}

?> 
           <td> <img src="data:image/jpg;charset=utf8;base64,<?php echo base64_encode($row['image']); ?>" height=50 width=40/></td></tr> 
        <?php } ?> 
    </div> 
<?php } ?> 
<style>
table
{
	width: 100%;

}
td
{
	text-align: center;
}
</style>